package com.graphql.graphql_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphqlProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
